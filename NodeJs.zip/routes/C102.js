'use strict';
var express = require('express');
var router=express.Router();
var data;
var minutes = 0.1, the_interval = minutes * 60 * 1000;
setInterval(function() {
  const fs = require('fs');

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("Test");
  var query = { CID: "C102" };
  dbo.collection("C102").find(query).toArray(function(err, result) {
    if (err) throw err;
    
    data=result[0];
    console.log(data);
    let dt = JSON.stringify(data);
    fs.writeFileSync('/home/ubuntu/reactjs/task-assignment/src/C102.json', dt);
    //data=result;
    db.close();
  });
});


router.get("/",function(req,res,next){
    res.send(data)
});
}, the_interval);

module.exports=router;